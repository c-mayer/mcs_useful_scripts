README - Final assignment - MBDS 2020 Grundlagen der Programmierung in Python - Dellinger, Himmelbauer, Mayer

Questions:
	1. Which genes are universally required for an organism to survive? More precisely: Which genes (OGs) occur in at least 99% of all genomes in the eggNOG5 database in each domain of life, respectively?
	   (The results should be around 100-300.)
	        A) How many such genes did you identify in each domain?

			There were 123 bacteria, 175 archaea and 273 eukaryota identified.

      	  	B) Provide the results as three files (one for each domain) listing the OGs in sorted order (by name).

			The created files were:
			cogs_bacteria_o99.txt for bacteria
			cogs_archaea_o99.txt for archaea
			cogs_eukaryota_o99.txt for eukaryota

	2. Which common bacterial genes occur almost exclusively as single-copy genes? More precisely: Which OGs occur in at least 50% of all bacterial genomes, and in at least 99% thereof as single-copy?
        	A) Provide the results as a sorted text file.

			The results are listed in this file: cogs_bacteria_o50_u99.txt

	        B) How many of these OGs were also identified as universal bacterial OGs (previous question)?

			There were 40 of these OGs identified as universal bacterial OGs.
			(Code: comm -12 cogs_bacteria_o99.txt cogs_bacteria_o50_u99.txt | wc -l --> 41 - header = 40)

	3. Identify all OGs that occur as single-copy in at least 97% of all Archaea.
        	A) How many such OGs did you identify? Provide the result as a sorted text file.

			There were 121 of such archaeal OGs identified
			Results were listed in this file: cogs_archaea_os97.txt

        	B) It would be interesting to know if there are archaeal genomes which substantially deviate from this "default" archaeal gene set. Are there Archaea which lack 4 or more of these universal OGs?
		   Which organism (scientific name) lacks most? What is its preferred growing temperature/environment?

			Yes, there are archaea which lack 4 or more universal OGs. Results are listed in here: func_cat_archaea_os97.txt
			The organism that lacks most is: Pyrococcus horikoshii. Its preferred growing temp. is 98°C. It is hyperthermophilic, anaerobic and found in hydrothermal vents. 
			It may very well be one of the earliest organisms to live on earth due to the big difference to the other archaea as well as its natural habitat.  

	4. Compile an overview of the functional categories of these 121 archaeal OGs.
        	Provide the result as a text file sorted by the number of the functional categories.

			The results are listed in the file below:
			func_cat_archaea_os97.txt

#!/usr/bin/env python

import sys
import gzip
from collections import Counter

"""Reads 3 input files in order to create a text file, in which the functional categories of the input are counted and listed."""

func_categories_file = sys.argv[1]
func_file = sys.argv[2]
# func_file = sys.stdin
cog_file = sys.argv[3]

# Initialize variables
category2description = {}
cog2category = {}
category2count = Counter()
my_cogs = set()


# Step 1: Read description of functional categories
with open(func_categories_file) as fin:
    for line in fin:
        if line[0] != " ":
            continue
        category, func_description = line.strip().split(" ", maxsplit=1)
        category2description[category[1]] = func_description


# Step 2: Read file with OGs of interest
with open(cog_file) as fin:
    for line in fin:
        if line[0] == "#":
            continue
        cog = line.strip().split("\t")[0]
        my_cogs.add(cog)


# Step 3: Read file with functional annotations
# and remember those for OGs of interest
# gzip: "rt" required for text mode, see https://docs.python.org/3/library/gzip.html
with gzip.open(func_file, "rt") as fin:
    for line in fin:
        if line[5] == "2":
            continue
        cog, category = line.strip().split("\t")[1:3]
        cog2category[cog] = list(category) # code in step 4 works also without seperating the letters into a list


# Step 4: Count and output the categories for OGs of interest
for mycog in my_cogs:
    if mycog in cog2category:
        category2count.update(cog2category[mycog])
for key, value in category2count.most_common():
    print(f"{value}\t{category2description[key]}")

#!/bin/bash

#SEQUENCING DATA
#create data subdirectory and download sample data
mkdir -p ./data && cd ./data
wget ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR628/000/SRR6281660/SRR6281660_1.fastq.gz
wget ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR628/000/SRR6281660/SRR6281660_2.fastq.gz
wget ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR628/001/SRR6281661/SRR6281661_1.fastq.gz
wget ftp://ftp.sra.ebi.ac.uk/vol1/fastq/SRR628/001/SRR6281661/SRR6281661_2.fastq.gz
cd ..


#REFERENCE DATA
#create refdata subdirectory and download reference data
mkdir -p ./refdata && cd ./refdata
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/005/845/GCF_000005845.2_ASM584v2/GCF_000005845.2_ASM584v2_genomic.fna.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/005/845/GCF_000005845.2_ASM584v2/GCF_000005845.2_ASM584v2_genomic.gtf.gz
gunzip -k GCF_000005845.2_ASM584v2_genomic.fna.gz
gunzip -k GCF_000005845.2_ASM584v2_genomic.gtf.gz
cd ..


#call snakemake and finish the job
snakemake --use-conda -j 1 variantcalling/SRR628166.variants.filtered.vcf

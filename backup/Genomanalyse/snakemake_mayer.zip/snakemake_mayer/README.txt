Please read this file carefully before executing any code!

Requirements for a run without bugs or errors:
	required data: 
		- snakefile
		- project.yaml
		- start_snakemake.sh
		- NexteraPE-PE.fa (in subdirectory refdata)
		- trimmomatic-0.36.jar archive 

	required installations:
		- snakemake (version used in testing: 5.31.1)
		- java (needed to be able to use the trimmomatic-0.36.jar archive; java version used by authors: 11.0.9.1)
		- bcftools (versions used in testing: 1.9; 1.10.2)
		- samtools (versions used in testing: 1.7; 1.10)
		- minimap2 (version used in testing: 2.17)

How to run this program:
	- conda activate "environment where snakemake is installed" (e.g. $ conda activate snakemake)
	- change working directory to directory where the required data is located (e.g. $ cd ~/......)
	- bash command to run the programm: $ bash start_snakemake.sh

Results will be written in a vcf-file in subdirectory variantcalling after the program has finished.



IMPORTANT NOTICE: 
If the sample data already exists, it is neccessary to hash the lines that download sample data (found in start_snakemake.sh in lines 6, 7, 8 and 9).


Authors: 
Dellinger, Himmelbauer, Mayer
